INFORMATION FOR SKINNERS
------------------------

https://kodi.wiki/view/Add-on:Skin_Widgets

version 0.0.33+matrix.4:
added new video item window property PercentPlayedAsInt which provides a number string (without "%") for use in progress controls
added new video item window property Runtimesecs for Music Videos provides formatted string 'min:sec'
added new property for Nexus HDRType
add new art property Art(icon)

