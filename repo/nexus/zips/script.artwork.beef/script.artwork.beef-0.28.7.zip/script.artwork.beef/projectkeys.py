# Do not use these API keys for any project other than Artwork Beef
# Do not distribute these API keys

FANARTTV_PROJECTKEY = '13756cf3472ff6b3dbffee20bed9c6ec'
TADB_PROJECTKEY = '5d656564694f534d656564'
TMDB_PROJECTKEY = '5a0727308f37da772002755d6c073aee'
THETVDB_PROJECTKEY = '8357F01B3F8F1393'